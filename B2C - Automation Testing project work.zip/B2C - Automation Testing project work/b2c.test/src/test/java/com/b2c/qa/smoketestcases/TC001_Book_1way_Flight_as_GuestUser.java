package com.b2c.qa.smoketestcases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.b2c.qa.pageobjects.FlightHomePage;
import com.b2c.qa.testbase.TestBase;
//import com.b2c.qa.utilities.ExcelDataReaderUtil;

//Book a one way flight as a Guest User.


public class TC001_Book_1way_Flight_as_GuestUser extends TestBase
	{				
		WebElement element;
		//WebDriver driver;	
	
	
		//Constructor
		public TC001_Book_1way_Flight_as_GuestUser() throws IOException
			{
					super();
			}


		@BeforeTest
	    void browserlaunch() throws InterruptedException, IOException

	    {
	        initialize();
	    }
		
		
		@Test
		public void FlightHomePage() throws IOException, Exception
			{
				FlightHomePage fhp = PageFactory.initElements(driver, FlightHomePage.class);
				
				fhp.flight_search_from();
				fhp.flight_search_to();
				fhp.flight_departure_date("20-04-2020");
				fhp.flight_add_child();
				fhp.flight_add_infant();
				fhp.clickondonebuttony();
				fhp.click_on_search();
				System.out.println("Read1");
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			}
	}
		





















//ExcelDataReaderUtil readexceldata = PageFactory.initElements(driver, ExcelDataReaderUtil.class);		
//String cellvaluefrom = readexceldata.readStringCell("B2C - Test Data", "Flight Booking - One Way", 1, 2);
//String cellvalueto = readexceldata.readStringCell("B2C - Test Data", "Flight Booking - One Way", 1, 3);
//String departuredate = readexceldata.readStringCell("B2C - Test Data", "Flight Booking - One Way", 1, 4);
//fhp.flight_departure_date(departuredate);






//{
//	e.printStackTrace();
			//ExcelDataReaderUtil readdata = new ExcelDataReaderUtil();
	//String valueincell = readdata.readStringCell("B2C - Test Data.xlsx", "Flight Booking - One Way", '1', '2');
	//flighthomesearch.flight_search_from(valueincell);
	//System.out.println(valueincell);

/*public static WebDriver initialize() throws IOException
{
	System.setProperty("webdriver.chrome.driver", "C:\\B2C - Automation Testing project work\\Selenium Resources\\Browser Drivers\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();	
	driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.navigate().to("http://13.232.248.121:8181/Search/flight");
	return driver;
}*/
