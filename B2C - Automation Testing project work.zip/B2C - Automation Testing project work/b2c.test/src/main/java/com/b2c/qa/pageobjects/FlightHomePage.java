package com.b2c.qa.pageobjects;

import java.io.IOException;
import java.util.Date;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.b2c.qa.testbase.TestBase;
import com.b2c.qa.utilities.ExcelDataReaderUtil; 


//************************************|| B2C - Home Page/Landing Page Object Repository (OR)||***************************************************************
														
	public class FlightHomePage extends TestBase
		{
			WebDriver driver;
			String text;
			String StringMaintext;
			String Stringsubtitle;

//**********************************************||	ALL TABS ON HOME PAGE	||*********************************************************************
				
				@FindBy(id= "flight")
				WebElement fhp_flights_Tab;
				
				@FindBy(id= "hotel")
				WebElement fhp__hotels_Tab;
				
				@FindBy(id = "holiday")
				WebElement fhp_holidays_Tab;
				
				@FindBy(id= "recharge")
				WebElement fhp_recharge_Tab;
						
//**********************************************||	ONE WAY/RETURN RADIO BUTTONS	||*********************************************************************
				
				@FindBy(id= "mat-radio-1-input")
				WebElement fhp_oneway_rb;
				
				@FindBy(id= "returnbg-input")
				WebElement fhp_twoway_rb;
									
//**********************************************||	FLIGHT SEARCH FORM	||*********************************************************************
				
				
				//Search "From"
				@FindBy(id= "mat-input-0")
				WebElement fhp_Search_from;
				
				//Search "to"
				@FindBy(id= "mat-input-1")
				WebElement fhp_Search_to;
				
				//Select "Departure date"
				@FindBy(id= "mat-input-2")
				WebElement fhp_departure_date;
				
					//Select "Year section" from date picker drop down
					@FindBy(className= "mat-button-wrapper")
					WebElement fhp_Departure_Date_selectyeardropdown;
					
					//Select "Year" from date picker window
					//@FindBy(className= "mat-calendar-body-cell-content")
					//WebElement fhp_Departure_Date_selectyearfromtable;
					
					
				//Select "Return date"			
				@FindBy(id= "mat-input-9")
				WebElement fhp_return_date;
							
				//click on "traveler details" field
				@FindBy(xpath= "//div[contains(@class,'traveler_detail')]")
				WebElement fhp_traveler_details;
				
																					
						//Add "Adult"
						@FindBy(xpath=  "//ul[contains(@class,'traveler_list')]/li[1]/div[2]/span[2]")
						WebElement fhp_add_adult;
						
						//Add "Child"
						@FindBy(xpath=  "//ul[contains(@class,'traveler_list')]/li[2]/div[2]/span[2]")
						WebElement fhp_add_child;
						
						//Add "Infant"
						@FindBy(xpath=  "//ul[contains(@class,'traveler_list')]/li[3]/div[2]/span[2]")
						WebElement fhp_add_infant;
						
						//Remove "Adult:
						@FindBy(xpath=  "//ul[contains(@class,'traveler_list')]/li[1]/div[2]/span[1]")
						WebElement fhp_remove_adult;
						
						//Remove "Child"
						@FindBy(xpath=  "//ul[contains(@class,'traveler_list')]/li[2]/div[2]/span[1]")
						WebElement fhp_remove_child;
						
						//Remove "Infant"
						@FindBy(xpath=  "//ul[contains(@class,'traveler_list')]/li[3]/div[2]/span[1]")
						WebElement fhp_remove_infant;
						
						//Select travel class "Any"
						@FindBy(xpath=  "//label[@for='mat-radio-15-input']/div[1]/div[1]")
						WebElement fhp_travelclass_any;
						
						//Select travel class "Economy"
						@FindBy(xpath=  "//label[@for='mat-radio-16-input']/div[1]/div[1]")
						WebElement fhp_travelclass_economy;
						
						//Select travel class "Business"
						@FindBy(xpath=  "//label[@for='mat-radio-17-input']/div[1]/div[1]")
						WebElement fhp_travelclass_business;
						
						//Select travel class "First Class"
						@FindBy(xpath=  "//label[@for='mat-radio-18-input']/div[1]/div[1]")
						WebElement fhp_travelclass_firstclass;
						
						//Select travel class "Premium Economy"
						@FindBy(xpath=  "//label[@for='mat-radio-19-input']/div[1]/div[1]")
						WebElement fhp_travelclass_premiumeconomy;
						
						//Click on "Done" button
						@FindBy(linkText=  "Done")
						WebElement fhp_travelerdetail_donebtn;
				
				//@FindBy(xpath= "/html/body/app-root/app-content-layout/div/div/div/app-search/div/div/div/div/div[1]/div[2]/app-search-flight/div/div/form/div/div/div/div/div[4]/div/a/img")
				//a[contains(@class,'respnonecls')]
				//@FindBy(xpath = "//*[@id=\"tab1\"]/div[1]/form[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]")
				//*[@id="tab1"]/div/form/div/div/div/div/div[4]/div
				//WebElement fhp_Search_btn;
				
//**********************************************||	FLIGHT SEARCH BUTTON	||*********************************************************************								
				
				@FindBy(className = "seachbtn")
				WebElement fhp_Search_btn;
																	


//**********************************************||	LINK -> "MY ACCOUNT"	||*********************************************************************
				
				@FindBy(id="navbarDropdownMenuLink")
				WebElement fhp_myaccount;

//**********************************************||	LINK -> "SUPPORT"	||*********************************************************************
				
				@FindBy(xpath= "//*[@id=\"navbarDropdownMenuLinks\"]")
				WebElement fhp_support;

//**********************************************||	LINK -> "MY BOOKINGS"	||*********************************************************************
					
				@FindBy(xpath= "//*[@id=\"navbarNavDropdown\"]/ul/li[2]/ul/li/a")
				WebElement fhp_find_mybookings;
			
//**********************************************||	LINK -> "OUR OFFERS"	||*********************************************************************

				@FindBy(xpath= "//*[@id=\"navbarNavDropdown\"]/ul/li[3]/a")
				WebElement fhp_our_offers;

				
//****************************************************|| Initialize all objects on the web page ||*********************************************
								
		public FlightHomePage(WebDriver driver) throws IOException
			{
				this.driver = driver;
				PageFactory.initElements(driver, this);
			}
		

//****************************************************|| ALL METHODS DECLARATIONS ON HOME PAGE ||***********************************************		
				
		public String verify_homepage_title()
			{
				return driver.getTitle();
			}
		
		public void click_on_flight_Tab()
			{
				fhp_flights_Tab.click();
			}
		public void validate_hotel_tab()
			{
				fhp__hotels_Tab.click();
			}
		public void validate_holiday_tab()
			{
				fhp_holidays_Tab.click();
			}
		public void validate_recharge_tab()
			{
				fhp_recharge_Tab.click();
			}
		
//FLIGHTS SEARCH FORM
		
		//Radio buttons
		public void select_oneway_rb()
			{
				fhp_oneway_rb.isSelected();
				fhp_oneway_rb.click();
			}
		public void select_twoway_rb()
			{
				fhp_twoway_rb.click();
			}		
		
		//Search flight from (source)
		public void flight_search_from() throws IOException, Exception
			{
				ExcelDataReaderUtil readexceldata = PageFactory.initElements(driver, ExcelDataReaderUtil.class);
				String cellvaluefrom = readexceldata.readStringCell("B2C - Test Data", "Flight Booking - One Way", 1, 2);
				fhp_Search_from.sendKeys(cellvaluefrom);
				//fhp_Search_from.sendKeys(Keys.ARROW_DOWN);
				fhp_Search_from.sendKeys(Keys.ENTER);
			}
		
		//Search flight to (destination)
		public void flight_search_to() throws IOException, Exception
			{
				ExcelDataReaderUtil readexceldata = PageFactory.initElements(driver, ExcelDataReaderUtil.class);
				String cellvalueto = readexceldata.readStringCell("B2C - Test Data", "Flight Booking - One Way", 1, 3);
				fhp_Search_to.sendKeys(cellvalueto);
				//fhp_Search_to.sendKeys(Keys.ARROW_DOWN);
				fhp_Search_to.sendKeys(Keys.ENTER);
			}
		

		//Date of departure
		public void flight_departure_date(String departure_date) throws IOException
		{
			try
				{
					//DatePicker date_picker = new DatePicker();
					//String pickdate = date_picker.departure_date_Picker(date_of_departure);
					//WebElement departure_date = driver.findElement(By.id("mat-input-2"));
				System.out.println(departure_date);
					fhp_departure_date.clear();
					System.out.println(departure_date);
					((JavascriptExecutor) driver).executeScript("arguments[0].removeAttribute('readonly','readonly')",fhp_departure_date);
					fhp_departure_date.sendKeys(Keys.CONTROL+"a"));
					
					fhp_departure_date.sendKeys(departure_date);
					System.out.println(departure_date);
				}
					catch (Exception e)
						{
					
						}
		}			
			
			
		//Date of Return	
		public void flight_return_date(CharSequence return_date)
			{
				
				fhp_return_date.sendKeys(return_date);
			}

	
		//Traveler details --> (No. of (Adults, Child & Infants)) + (Class of travels selection)
			public void flight_traveler_details()
			{ 
				fhp_traveler_details.click();
			}
						public void flight_add_adult()
						{
							fhp_add_adult.click();
						}
						
						public void flight_remove_adult()
						{
							fhp_remove_adult.click();
						}
						
						public void flight_add_child()
						{
							fhp_add_child.click();
						}
						
						public void flight_remove_child()
						{
							fhp_remove_child.click();
						}
								
						public void flight_add_infant()
						{
							fhp_add_infant.click();
						}
						
						public void flight_remove_infant()
						{
							fhp_remove_infant.click();
						}
						
						public void flight_travel_class_any()
						{
							fhp_travelclass_any.click();
						}
						public void flight_travel_class_economy()
						{
							fhp_travelclass_economy.click();
						}
						public void flight_travel_class_business()
						{
							fhp_travelclass_business.click();
						}
						public void flight_travel_class_firstclass()
						{
							fhp_travelclass_firstclass.click();
						}
						public void flight_travel_class_premiumeconomy()
						{
							fhp_travelclass_premiumeconomy.click();
						}
						public void clickondonebuttony()
						{
							fhp_travelerdetail_donebtn.click();
						}
				
			//Click on "Search Button"
			public void click_on_search()
			{
				//fhp_Search_btn.click();
				fhp_Search_btn.click();
				System.out.println("Clicked oin searched button");
			}
	}