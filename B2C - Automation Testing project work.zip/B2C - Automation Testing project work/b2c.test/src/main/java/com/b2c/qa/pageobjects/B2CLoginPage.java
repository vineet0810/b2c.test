package com.b2c.qa.pageobjects;


import java.io.IOException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.b2c.qa.testbase.TestBase;


	public class B2CLoginPage extends TestBase
		{
			
			@FindBy(id="mat-input-0")
			WebElement fhp_myaccount_username;
			@FindBy(id= "mat-input-1")
			WebElement fhp_myaccount_password;
			@FindBy(xpath= "//button[contains(@class,'chenges')]")
			WebElement fhp_myaccount_loginbtn;
		
	
			public B2CLoginPage() throws IOException
				{
				super();
				}
		
}