package com.b2c.qa.utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.b2c.qa.testbase.TestBase;

public class DatePicker extends TestBase
	{
		static WebDriver driver;
		boolean depart_date_set;
			
		public DatePicker() throws Exception
				{
					super();
				}
		
			public void departure_date_Picker(String date_of_departure)
				{
					WebElement departure_date = driver.findElement(By.id("mat-input-2"));
					((JavascriptExecutor) driver).executeScript("arguments[0].removeAttribute('readonly','readonly')",departure_date);
					System.out.println(departure_date);
					//return (depart_date_set);
				}
	}
