package com.b2c.qa.testbase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class TestBase {                                           

	public WebDriver driver;
	public Properties prop;
		
	
	
		//Read config.property file for constant data
		public TestBase() throws IOException
			{
				try
					{
						prop = new Properties();
						FileInputStream inputdata = new FileInputStream("C:/B2C - Automation Testing project work/b2c.test/src/main/java/com/b2c/qa/configproperties/config.properties");
						prop.load(inputdata);
					} 
					catch (FileNotFoundException e)
						{
							e.printStackTrace();
						}
					catch (IOException e)
						{
							e.printStackTrace();
						}
			}
	
	
		
		//Initialize Chrome driver, launch browser and open the landing page
		public WebDriver initialize() throws IOException
			{
				System.setProperty("webdriver.chrome.driver", "C:\\B2C - Automation Testing project work\\Selenium Resources\\Browser Drivers\\chromedriver.exe");
				driver = new ChromeDriver();	
				//driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.navigate().to("http://13.232.248.121:8181/Search/flights");
				return driver;
			}
	
		
		
		//Wait the script for further execution
		public void scriptsleeptime()
			{
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			}
	
	
		
		//Execute after test to release resources
		public void tearDown()
			{
				driver.quit();
				//driver.close();
			}


		
		//Write data into Excel cell
		public void writeIntoCell(int row_number, int cell_number,String data) throws IOException
			{		
				File file =  new File("C:\\B2C - Automation Testing project work\\b2c.test\\src\\main\\java\\com\\b2c\\qa\\testdata\\B2C - Test Data.xlsx");
				FileInputStream inputStream = new FileInputStream(file); 
				XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
				XSSFSheet sheet = workbook.getSheet("Flight Booking - One Way"); 
				Row row = sheet.getRow(row_number);    
				Cell cell = row.getCell(cell_number, MissingCellPolicy.CREATE_NULL_AS_BLANK);
				cell.setCellValue(data);
		
				FileOutputStream outputStream = new FileOutputStream(file,false);
				workbook.write(outputStream);
				outputStream.flush();
				outputStream.close();
				workbook.close();		
			}


		
		//Read data into Excel cells
		public String readFromCell(int row_number, int cell_number) throws IOException
			{
				File file = new File("C:\\B2C - Automation Testing project work\\b2c.test\\src\\main\\java\\com\\b2c\\qa\\testdata\\B2C - Test Data.xlsx"); 
				FileInputStream inputStream = new FileInputStream(file);
				XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
				XSSFSheet sheet = workbook.getSheet("Flight Booking - One Way"); 
		
				Row row = sheet.getRow(row_number);    
				Cell cell = row.getCell(cell_number,MissingCellPolicy.RETURN_BLANK_AS_NULL);
		
				Double  dvalue = cell.getNumericCellValue();
				Integer value = dvalue.intValue() ;
				String  celldata = value.toString();
				workbook.close();
				return celldata;
			}



		//Read all string type of data from cell
		public String readStringCell(String fileName,String sheetName ,int rownumber, int cellnumber) throws IOException
			{
				File file = new File("C:\\B2C - Automation Testing project work\\b2c.test\\src\\main\\java\\com\\b2c\\qa\\testdata\\B2C - Test Data.xlsx");
				FileInputStream inputStream = new FileInputStream(file); 
				XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
				XSSFSheet sheet = workbook.getSheet("Flight Booking - One Way"); 
				Row row = sheet.getRow(rownumber);
				Cell cell = (Cell) row.getCell(cellnumber,MissingCellPolicy.RETURN_BLANK_AS_NULL);
				String  celldata = ((org.apache.poi.ss.usermodel.Cell) cell).getStringCellValue();
				workbook.close();
				return celldata;
			}

		
		
		//Read all numeric type of data from cell
		public Integer readNumericCell(String fileName,String sheetName ,int rownumber, int cellnumber) throws IOException
			{
				File file = new File("C:\\B2C - Automation Testing project work\\b2c.test\\src\\main\\java\\com\\b2c\\qa\\testdata\\B2C - Test Data.xlsx");
				FileInputStream inputStream = new FileInputStream(file);
				XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
				XSSFSheet sheet = workbook.getSheet("Flight Booking - One Way");
				
				Row row = sheet.getRow(rownumber);
				Cell cell = row.getCell(cellnumber,MissingCellPolicy.RETURN_BLANK_AS_NULL);
				
				Double  dvalue = cell.getNumericCellValue();
				Integer value = dvalue.intValue() ;
				
				workbook.close();
				return value;
			}

		
		//Delete column
		public void deleteColumn(String fileName,String sheetName ,int columnNum) throws IOException
			{
				File file = new File("C:\\B2C - Automation Testing project work\\b2c.test\\src\\main\\java\\com\\b2c\\qa\\testdata\\B2C - Test Data.xlsx");
				FileInputStream inputStream = new FileInputStream(file);
				XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
				XSSFSheet sheet = workbook.getSheet("Flight Booking - One Way");
		
					int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();
					for (int i = 1; i <= rowCount; i++)
						{
							Row row = sheet.getRow(i);
							Cell cell = row.getCell(columnNum,MissingCellPolicy.CREATE_NULL_AS_BLANK);
							((org.apache.poi.ss.usermodel.Cell) cell).setCellValue("");
							FileOutputStream outputStream = new FileOutputStream(file,false);
							workbook.write(outputStream);
							outputStream.flush();
							outputStream.close();
						}
				workbook.close();
			}
	}
		
 













//iver object to TakeScreenshot
//Step 2) Call getScreenshotAs method to create image file
//Step 3) Copy file to Desired Location
	
	/*public void autocompleteselectValuesfromdropdown (String search_city, String mypath)
	{System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		FirefoxDriver driver = new FirefoxDriver();
		driver.get("http://13.232.248.121:8181/flight");
		driver.findElement(By.xpath("mypath")).sendKeys(search_city);
		Example for Visibility of Elements located by
		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//ul[@role='listbox']//li")));
		List<WebElement> list = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
		System.out.println("Auto Suggest List ::" + list.size());
		for(int i = 0 ;i< list.size();i++)
		{ System.out.println(list.get(i).getText());
			if(list.get(i).getText().equals("selenium interview questions"))
			{	list.get(i).click();
				break;}	}	}*/

