package com.b2c.qa.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.b2c.qa.testbase.TestBase;

public class ExcelDataReaderUtil extends TestBase
	{ 
	//Constructor of the class
	public ExcelDataReaderUtil() throws IOException 
		{
			super();			
		}

			//Method to write into the excel cell
			public void writeIntoCell(int row_number, int cell_number,String data) throws IOException
				{		
					File file =  new File("C:\\B2C - Automation Testing project work\\b2c.test\\src\\main\\java\\com\\b2c\\qa\\testdata\\B2C - Test Data.xlsx");
					FileInputStream inputStream = new FileInputStream(file); 
					XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
					XSSFSheet sheet = workbook.getSheet("Flight Booking - One Way"); 
					Row row = sheet.getRow(row_number);    
					Cell cell = row.getCell(cell_number, MissingCellPolicy.CREATE_NULL_AS_BLANK);
					cell.setCellValue(data);

					FileOutputStream outputStream = new FileOutputStream(file,false);
					workbook.write(outputStream);
					outputStream.flush();
					outputStream.close();
					workbook.close();		
				}
	
	
			//Method to read data from cells
			public String readFromCell(int row_number, int cell_number) throws IOException
				{
					File file = new File("C:\\B2C - Automation Testing project work\\b2c.test\\src\\main\\java\\com\\b2c\\qa\\testdata\\B2C - Test Data.xlsx"); 
					FileInputStream inputStream = new FileInputStream(file);
					XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
					XSSFSheet sheet = workbook.getSheet("Flight Booking - One Way"); 
        
					Row row = sheet.getRow(row_number);    
					Cell cell = row.getCell(cell_number,MissingCellPolicy.RETURN_BLANK_AS_NULL);
       
					Double  dvalue = cell.getNumericCellValue();
					Integer value = dvalue.intValue() ;
					String  celldata = value.toString();
        			
					workbook.close();
        			
        			return celldata;
				}
	

			//Method to read string type of data from cell
			public String readStringCell(String fileName,String sheetName ,int rownumber, int cellnumber) throws IOException
				{
					File file = new File("C:\\B2C - Automation Testing project work\\b2c.test\\src\\main\\java\\com\\b2c\\qa\\testdata\\B2C - Test Data.xlsx");
					FileInputStream inputStream = new FileInputStream(file); 
					XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
					XSSFSheet sheet = workbook.getSheet("Flight Booking - One Way"); 
					Row row = sheet.getRow(rownumber);
					Cell cell = (Cell) row.getCell(cellnumber,MissingCellPolicy.RETURN_BLANK_AS_NULL);
					String  celldata = ((org.apache.poi.ss.usermodel.Cell) cell).getStringCellValue();
					workbook.close();
					return celldata;
				}
			
			
			//Method to read numeric type of data from cell
			public Integer readNumericCell(String fileName,String sheetName ,int rownumber, int cellnumber) throws IOException
				{
					File file = new File("C:\\B2C - Automation Testing project work\\b2c.test\\src\\main\\java\\com\\b2c\\qa\\testdata\\B2C - Test Data.xlsx");
					FileInputStream inputStream = new FileInputStream(file);
					XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
					XSSFSheet sheet = workbook.getSheet("Flight Booking - One Way");
					
					Row row = sheet.getRow(rownumber);
					Cell cell = row.getCell(cellnumber,MissingCellPolicy.RETURN_BLANK_AS_NULL);
					
					Double  dvalue = cell.getNumericCellValue();
					Integer value = dvalue.intValue() ;
					
					workbook.close();
					return value;
				}


			public void deleteColumn(String fileName,String sheetName ,int columnNum) throws IOException
				{
					File file = new File("C:\\B2C - Automation Testing project work\\b2c.test\\src\\main\\java\\com\\b2c\\qa\\testdata\\B2C - Test Data.xlsx");
					FileInputStream inputStream = new FileInputStream(file);
					XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
					XSSFSheet sheet = workbook.getSheet("Flight Booking - One Way");

					int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();
					for (int i = 1; i <= rowCount; i++)
						{
							Row row = sheet.getRow(i);
							Cell cell = row.getCell(columnNum,MissingCellPolicy.CREATE_NULL_AS_BLANK);
							((org.apache.poi.ss.usermodel.Cell) cell).setCellValue("");
							FileOutputStream outputStream = new FileOutputStream(file,false);
							workbook.write(outputStream);
							outputStream.flush();
							outputStream.close();
						}
					workbook.close();
				}
		}