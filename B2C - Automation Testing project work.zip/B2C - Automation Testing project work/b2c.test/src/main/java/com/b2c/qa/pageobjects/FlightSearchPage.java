	package com.b2c.qa.pageobjects;
	
	import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	import com.b2c.qa.testbase.TestBase;

//****************************************[ Initialize all objects on the web page ]******************************************************
	
public class FlightSearchPage extends TestBase
		{	
			public WebDriver driver;
			String text;
			String StringMaintext;
			String Stringsubtitle;

	
			@FindBy(xpath = "(//a[contains(text(),'Book Now')])[1]")
			WebElement fsp_bookknow;
								
			@FindBy(xpath = "(//a[contains(text(),'Baggage Detail')])[1]")
			WebElement fsp_baggage_details;
			
			@FindBy(xpath = "//tr[contains(@class,'backthead')]/th[1]")
			WebElement fsp_baggage_type;				
				
			@FindBy(xpath = "//tr[contains(@class,'backthead')]/th[2]")
			WebElement fsp_baggage_weight;
		
			@FindBy(xpath = "(//a[contains(text(),'Flight Detail')])[1]")
			WebElement fsp_Flight_Detail;
		
			@FindBy(xpath = "(//span[contains(@class,'flghtdtlcls')]")
			WebElement fsp_Flight_Sub_Detail;
				
			@FindBy(xpath = "(//a[contains(text(),'Fare Detail')])[1]")
			WebElement fsp_Fare_Detail;
		
			@FindBy(xpath = "(//a[contains(text(),'Fare Detail')])[1]")
			WebElement fsp_Fare_Sub_Detail;
			
			@FindBy(xpath = "(//a[contains(text(),'Fare Detail')])[1]")
			WebElement fsp_Fare_Rules;
					
			@FindBy(xpath = "//div[contains(@class,'modal-content')]/app-fare-rule")
			WebElement fsp_Fare_Rules_popup_window;
		

//************************************|| Initialize all objects on the web page ||*********************************************************************

		public FlightSearchPage(WebDriver driver) throws IOException
			{
				this.driver = driver;
				PageFactory.initElements(driver, this);
			}
				
		
//**********************************************************|| Actions on WebElements ||*********************************************************** 
		
		public String verify_homepage_title()
			{
				return driver.getTitle();
			}
			
		public void click_on_book_now()
			{
				fsp_bookknow.click();
			}

		
		
		public void click_baggage_details()
			{
				fsp_baggage_details.click();
			}
				
			public void click_on_baggage_type()
				{
				fsp_baggage_type.click();
				}
			public void click_on_baggage_weight()
				{
				fsp_baggage_weight.click();
				}	
			
			
			
		public void click_on_Fare_Detail()
			{
			 	fsp_Fare_Detail.click();
			}	
			public void click_on_Fare_Sub_Detail()
				{
					fsp_Fare_Sub_Detail.click();
				}
			
			
		public void click_on_Fare_Rules()
			{
				fsp_Fare_Rules.click();
			}	
}

		
		
		
		
		